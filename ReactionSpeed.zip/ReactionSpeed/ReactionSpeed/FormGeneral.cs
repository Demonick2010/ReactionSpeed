﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace ReactionSpeed
{
    public partial class FormGeneral : Form
    {
        int totalClicks = 10;
        int click_nr = -1;
        int reactTime_ms = 0;
        int my_card_nr = 0;
        int waiting = 0;
        int min_waiting = 1;
        int max_waiting = 4;

        Stopwatch watch = new Stopwatch();

        static Random rnd = new Random();
        public FormGeneral()
        {
            InitializeComponent();
            progress.Maximum = totalClicks;
        }

        private void ShowCard(int nr)
        {
            pictureBox_img1.Visible = nr == 1;
            pictureBox_img2.Visible = nr == 2;
            pictureBox_img3.Visible = nr == 3;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (click_nr < 0)
                return;
            if (waiting > 0)
            {
                waiting--;
                if (waiting == 0)
                {
                    my_card_nr = rnd.Next(1, 4);
                    ShowCard(my_card_nr);

                    watch.Restart();
                }
            }
        }

        private void button_start_Click(object sender, EventArgs e)
        {
                switch (trackBar1.Value)
                {
                    case 0: max_waiting = 4; break;
                    case 1: max_waiting = 2; break;
                    case 2: max_waiting = 1; break;
                }
            

            click_nr = 0;
            reactTime_ms = 0;

            button_start.Enabled = false;

            NextClick();
        }

        private void NextClick()
        {
            ShowCard(0);
            click_nr++;
            waiting = rnd.Next(min_waiting * 1000 / timer.Interval, max_waiting * 1000 / timer.Interval + 1);

        }

        private void pictureBox_img1_Click(object sender, EventArgs e)
        {
            watch.Stop();
            reactTime_ms += (int)watch.ElapsedMilliseconds;
            progress.Value = click_nr;

            if (click_nr >= totalClicks)
                ShowResult();
            else
            NextClick();
        }

        private void ShowResult()
        {
            double sec = reactTime_ms / 1000.0 / totalClicks;

            MessageBox.Show("Среднее время реакции: " + sec.ToString("0.000") + "секунд", "Результат");

            button_start.Enabled = true;
            click_nr = -1;
        }
    }
}
